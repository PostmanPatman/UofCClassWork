﻿CREATE TABLE [dbo].[ExtractProducts]
(
	ProductCode INT,
	ProductName NVARCHAR(50),
	RawMaterial NVARCHAR(50),
	AmountOfRawMaterial DEC(18,3),
	ProductSubtypeName NVARCHAR(50),
	ProductTypeName NVARCHAR(50),
	ProductTypeShortName NVARCHAR(12),
)
