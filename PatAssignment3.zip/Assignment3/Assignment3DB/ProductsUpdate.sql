﻿CREATE TABLE [dbo].[ProductsUpdate]
(
	ID INT
)
