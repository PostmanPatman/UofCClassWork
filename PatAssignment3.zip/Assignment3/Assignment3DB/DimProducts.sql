﻿CREATE TABLE [dbo].[DimProducts]
(
	ProductSID INT IDENTITY (1,1) PRIMARY KEY,
	ProductCode INT,
	ProductName NVARCHAR(50),
	RawMaterial NVARCHAR(50),
	AmountOfRawMaterial DEC(18,3),
	ProductSubtypeName NVARCHAR(50),
	ProductTypeName NVARCHAR(50),
	ProductTypeShortName NVARCHAR(12),
	[Type2Hash] VARCHAR(32),
	CurFlg BIT NOT NULL,
	DelFlg BIT NOT NULL,
	[FromDateTime] DATETIME NOT NULL,
	[ToDateTime] DATETIME NOT NULL
)
