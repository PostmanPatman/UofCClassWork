﻿use MaxMinSalesDM
go
Create Schema [ETL]