﻿use MaxMinSalesDM
go
Create Schema [FACT]