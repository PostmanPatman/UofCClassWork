﻿use MaxMinSalesDM
go
Create Schema [STAGE]