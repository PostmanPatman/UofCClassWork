﻿CREATE TABLE [FACT].[DailySales](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[FK_Date] [datetime] NULL,
	[FK_Customer] [int] NULL,
	[FK_Product] [int] NULL,
	[FK_Promotion] [int] NULL,
	[FK_Sales_Person] [int] NULL,
	[FK_Store] [int] NULL,
	[Sales_in_Dollars] [money] NULL,
	[Sales_in_Units] [int] NULL,
	[Sales_Tax] [money] NULL,
	[Shipping] [money] NULL
	)
