﻿use MaxMinSalesDM
go

Create Table [ETL].[PackageDataFlowDates]
	(
	PackageName nvarchar(255) null,
	FromDate datetime null,
	ToDate datetime null
	)